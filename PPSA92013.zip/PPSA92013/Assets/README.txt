WWE '13 for PS5 - your game folder goes here.

Copy everything inside your WWE 13 game folder into this Assets folder:
default.xex, default.xexp (title update 2.0.1.0), and the game's folders
(pac, sound, ...). The same folder WWE '13 Recomp uses on PC.

DLC: put the DLC package files (as downloaded) in PPSA92013/UserData/DLC/,
or on a USB drive, and install them on the hub's DLC page. Or copy the
0000000000000000 folder from WWE '13 Recomp's userdata folder on PC into
PPSA92013/UserData/ (that's DLC the PC launcher already installed).
